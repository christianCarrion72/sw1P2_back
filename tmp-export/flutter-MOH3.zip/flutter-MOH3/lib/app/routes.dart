import '../pages/pantalla1/pantalla1_page.dart';

import 'package:flutter/material.dart';
final Map<String, WidgetBuilder> appRoutes = {
'/pantalla1': (context) => const Pantalla1Page(),};