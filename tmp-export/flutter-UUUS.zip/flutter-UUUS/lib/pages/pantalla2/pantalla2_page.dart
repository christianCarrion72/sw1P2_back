import 'package:flutter/material.dart';

class Pantalla2Page extends StatelessWidget {
  const Pantalla2Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2196f3),
        title: const Text(''),
        centerTitle: true,
      ),
      body: Container(),
    );
  }
}